PAIRTREE LIBRARY
Version ${pom.version}
Pairtree Version ${pairtree.version}

DESCRIPTION:
The PAIRTREE LIBRARY is a software library that supports the mapping between
identifiers and filepaths according to the Pairtree Specification
(https://confluence.ucop.edu/display/Curation/PairTree).

REQUIREMENTS:
Java 6

RELEASE NOTES:
Changes in 1.1.1:
1. Added correct license information.

Changes in 1.1:
1. Updated to most current version of spec by adding hexing of \.

Changes in 1.0:
Initial release that supports mapping between identifiers and paths.  Pairtree
initiation is not supported.

For questions or problems, contact Justin Littman (jlit@loc.gov).